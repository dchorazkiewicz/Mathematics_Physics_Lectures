Source package for the PDF lecture notes:
The Bohr Model of the Atom: Quantization and the Origin of Spectral Lines

Compile with:
pdflatex bohr_atom_notes.tex
pdflatex bohr_atom_notes.tex

The notes are written in English for computer science students, with minimal mathematics needed to derive the Bohr radii, energy levels, Rydberg formula, and Balmer series.
