# Ideal Gas Theory - LaTeX source

Compile with:

```bash
pdflatex -interaction=nonstopmode ideal_gas_lecture_notes.tex
pdflatex -interaction=nonstopmode ideal_gas_lecture_notes.tex
```

The document uses standard LaTeX packages: amsmath, siunitx, TikZ, pgfplots, booktabs, enumitem, hyperref and fancyhdr.
