#!/usr/bin/env bash
set -euo pipefail
pdflatex -interaction=nonstopmode ideal_gas_lecture_notes.tex
pdflatex -interaction=nonstopmode ideal_gas_lecture_notes.tex
