import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / 'figures'
OUT.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'font.size': 11,
    'axes.titlesize': 12,
    'axes.labelsize': 10,
    'figure.dpi': 160,
})

blue = '#1f77b4'
orange = '#ff7f0e'
green = '#2ca02c'
red = '#d62728'
purple = '#9467bd'
gray = '#555555'
light = '#f2f5f7'


def setup_axis(ax, xlim=(-1,5), ylim=(-1,4), equal=True):
    ax.axhline(0, color='black', linewidth=0.8)
    ax.axvline(0, color='black', linewidth=0.8)
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.grid(True, linewidth=0.5, alpha=0.35)
    if equal:
        ax.set_aspect('equal', adjustable='box')
    for spine in ['top','right']:
        ax.spines[spine].set_visible(False)


def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / f'{name}.pdf', bbox_inches='tight')
    fig.savefig(OUT / f'{name}.png', bbox_inches='tight')
    plt.close(fig)

# 1 coordinate system
fig, ax = plt.subplots(figsize=(5.2,3.8))
setup_axis(ax, (-1,4.2), (-1,3.4))
ax.arrow(0,0,1,0, head_width=.10, head_length=.15, fc=blue, ec=blue, linewidth=2, length_includes_head=True)
ax.arrow(0,0,0,1, head_width=.10, head_length=.15, fc=orange, ec=orange, linewidth=2, length_includes_head=True)
ax.text(1.08,.1,r'$e_1=(1,0)$', color=blue)
ax.text(.1,1.1,r'$e_2=(0,1)$', color=orange)
P = np.array([3,2])
ax.plot(P[0], P[1], 'o', color=red)
ax.plot([P[0],P[0]],[0,P[1]], '--', color=gray, alpha=.8)
ax.plot([0,P[0]],[P[1],P[1]], '--', color=gray, alpha=.8)
ax.text(P[0]+.1,P[1]+.1,r'$P=(3,2)$')
ax.set_title('Cartesian coordinates encode a point by two numbers')
save(fig, 'cartesian_coordinates')

# 2 vector decomposition
fig, ax = plt.subplots(figsize=(5.2,3.8))
setup_axis(ax, (-1,4), (-1,4))
v=np.array([3,2.6])
ax.arrow(0,0,v[0],v[1], head_width=.12, head_length=.18, fc=purple, ec=purple, linewidth=2, length_includes_head=True)
ax.arrow(0,0,v[0],0, head_width=.1, head_length=.15, fc=blue, ec=blue, linewidth=2, length_includes_head=True)
ax.arrow(v[0],0,0,v[1], head_width=.1, head_length=.15, fc=orange, ec=orange, linewidth=2, length_includes_head=True)
ax.text(1.25, -.35, r'$v_x e_1$', color=blue)
ax.text(3.12, 1.1, r'$v_y e_2$', color=orange)
ax.text(1.6, 1.55, r'$v=v_xe_1+v_ye_2$', color=purple)
ax.set_title('Vector decomposition in a basis')
save(fig, 'vector_decomposition')

# 3 projection
fig, ax = plt.subplots(figsize=(5.2,3.6))
setup_axis(ax, (-.5,5), (-.5,3.5))
a=np.array([4.2,0.8]); b=np.array([3.5,2.4]); ahat=a/np.linalg.norm(a)
proj = np.dot(b,ahat)*ahat
ax.arrow(0,0,a[0],a[1], head_width=.1, head_length=.16, fc=blue, ec=blue, linewidth=2, length_includes_head=True)
ax.arrow(0,0,b[0],b[1], head_width=.1, head_length=.16, fc=red, ec=red, linewidth=2, length_includes_head=True)
ax.arrow(0,0,proj[0],proj[1], head_width=.1, head_length=.16, fc=green, ec=green, linewidth=2, length_includes_head=True)
ax.plot([b[0],proj[0]],[b[1],proj[1]], '--', color=gray)
ax.text(a[0]+.05,a[1],r'$a$', color=blue)
ax.text(b[0]+.05,b[1],r'$b$', color=red)
ax.text(proj[0]/2,proj[1]/2-.25,r'${\rm proj}_a b$', color=green)
ax.set_title('Dot products measure projection')
save(fig, 'dot_product_projection')

# 4 cross product area
fig, ax = plt.subplots(figsize=(5.2,3.8))
setup_axis(ax, (-.5,4.5), (-.5,3.5))
u=np.array([3.2,.7]); v=np.array([1.0,2.2])
poly=np.array([[0,0],u,u+v,v])
ax.fill(poly[:,0], poly[:,1], color=light, edgecolor=gray, linewidth=1.5)
ax.arrow(0,0,u[0],u[1], head_width=.1, head_length=.15, fc=blue, ec=blue, linewidth=2, length_includes_head=True)
ax.arrow(0,0,v[0],v[1], head_width=.1, head_length=.15, fc=orange, ec=orange, linewidth=2, length_includes_head=True)
ax.text(u[0]+.08,u[1],r'$u$', color=blue)
ax.text(v[0]+.05,v[1]+.05,r'$v$', color=orange)
ax.text(1.65,1.55,r'area $=|\det[u\ v]|$')
ax.set_title('The 2D cross product / determinant gives oriented area')
save(fig, 'determinant_area')

# 5 line forms
fig, ax = plt.subplots(figsize=(5.2,3.8))
setup_axis(ax, (-1,5), (-1,4))
p=np.array([1,1]); d=np.array([3,1.5]); n=np.array([-d[1],d[0]])/np.linalg.norm(d)
t=np.linspace(-.7,1.25,100)
pts=p[:,None]+d[:,None]*t
ax.plot(pts[0], pts[1], color=blue, linewidth=2)
ax.plot(p[0],p[1],'o',color=red)
ax.arrow(p[0],p[1],d[0]*.45,d[1]*.45, head_width=.1, head_length=.14, fc=blue, ec=blue, linewidth=1.8, length_includes_head=True)
ax.arrow(p[0],p[1],n[0]*.9,n[1]*.9, head_width=.1, head_length=.14, fc=orange, ec=orange, linewidth=1.8, length_includes_head=True)
ax.text(p[0]+.1,p[1]-.35,r'$p$')
ax.text(p[0]+1.2,p[1]+.45,r'direction $d$', color=blue)
ax.text(p[0]-.8,p[1]+.8,r'normal $n$', color=orange)
ax.text(.3,3.2,r'$x=p+td$', color=blue)
ax.text(2.6,.35,r'$n\cdot(x-p)=0$', color=orange)
ax.set_title('A line may be described parametrically or implicitly')
save(fig, 'line_forms')

# 6 point to line distance
fig, ax = plt.subplots(figsize=(5.2,3.8))
setup_axis(ax, (-1,5), (-.5,4))
p=np.array([.6,.8]); d=np.array([3.8,1.1]); q=np.array([3.2,3.0])
t=np.linspace(-.2,1.15,100); pts=p[:,None]+d[:,None]*t
ax.plot(pts[0],pts[1],color=blue,lw=2)
w=q-p; proj=p+np.dot(w,d)/np.dot(d,d)*d
ax.plot(q[0],q[1],'o',color=red); ax.plot(proj[0],proj[1],'o',color=green)
ax.plot([q[0],proj[0]],[q[1],proj[1]],'--',color=gray,lw=2)
ax.text(q[0]+.08,q[1]+.08,r'$q$')
ax.text(proj[0]+.08,proj[1]-.3,r'$p+td$')
ax.text((q[0]+proj[0])/2+.1,(q[1]+proj[1])/2,r'$\mathrm{dist}(q,L)$')
ax.set_title('Distance from a point to a line is a perpendicular distance')
save(fig, 'point_line_distance')

# 7 affine transform square
fig, ax = plt.subplots(figsize=(5.2,3.8))
setup_axis(ax, (-.5,5), (-.5,4))
sq=np.array([[0,0],[1,0],[1,1],[0,1],[0,0]])
A=np.array([[2.0,.8],[.5,1.4]]); b=np.array([2.0,.8])
tr=(A@sq.T).T+b
ax.plot(sq[:,0],sq[:,1],'-o',color=blue,label='original')
ax.plot(tr[:,0],tr[:,1],'-o',color=red,label='affine image')
for i in range(4):
    ax.plot([sq[i,0],tr[i,0]],[sq[i,1],tr[i,1]],':',color=gray,alpha=.5)
ax.text(.15,.45,r'$S$')
ax.text(3.1,2.1,r'$AS+b$')
ax.legend(frameon=False, loc='upper left')
ax.set_title('Affine transformations preserve lines and parallelism')
save(fig, 'affine_transform')

# 8 barycentric coordinates
fig, ax = plt.subplots(figsize=(5.2,3.8))
setup_axis(ax, (-.5,4.5), (-.5,3.5))
A=np.array([.5,.5]); B=np.array([4,.7]); C=np.array([1.4,3.0]); P=np.array([1.9,1.45])
tri=np.array([A,B,C,A])
ax.fill(tri[:,0],tri[:,1],color=light,edgecolor=blue,lw=2)
for point,label in [(A,'A'),(B,'B'),(C,'C')]:
    ax.plot(point[0],point[1],'o',color=blue); ax.text(point[0]+.06,point[1]+.06,label)
ax.plot(P[0],P[1],'o',color=red); ax.text(P[0]+.08,P[1]+.08,r'$P$')
for point in [A,B,C]:
    ax.plot([P[0],point[0]],[P[1],point[1]],'--',color=gray,alpha=.7)
ax.text(.75,3.18,r'$P=\alpha A+\beta B+\gamma C$', fontsize=11)
ax.text(1.0,2.88,r'$\alpha+\beta+\gamma=1$')
ax.set_title('Barycentric coordinates describe points relative to a simplex')
save(fig, 'barycentric_coordinates')

# 9 orientation test
fig, ax = plt.subplots(figsize=(5.2,3.8))
setup_axis(ax, (-.5,5), (-.5,4))
poly=np.array([[.5,.5],[4,.8],[3.4,2.7],[1.5,3.2],[.5,.5]])
ax.fill(poly[:,0],poly[:,1],color=light,edgecolor=blue,lw=2)
for i,pt in enumerate(poly[:-1]):
    ax.plot(pt[0],pt[1],'o',color=blue); ax.text(pt[0]+.06,pt[1]+.06,fr'$p_{i}$')
ax.arrow(poly[0,0],poly[0,1],poly[1,0]-poly[0,0],poly[1,1]-poly[0,1], head_width=.1,head_length=.15, fc=green, ec=green, length_includes_head=True)
ax.text(1.7,1.95,r'$\frac{1}{2}\sum_i \det(p_i,p_{i+1})$')
ax.set_title('Signed area detects orientation and polygon area')
save(fig, 'polygon_signed_area')

# 10 3D plane projection (simple wireframe)
from mpl_toolkits.mplot3d import Axes3D  # noqa
fig = plt.figure(figsize=(5.2,4.0))
ax = fig.add_subplot(111, projection='3d')
xx, yy = np.meshgrid(np.linspace(-1,3,2), np.linspace(-1,3,2))
zz = 0.35*xx + 0.15*yy + .3
ax.plot_surface(xx, yy, zz, alpha=.25, color=blue, edgecolor=gray)
P=np.array([2.4,1.8,2.2])
n=np.array([-0.35,-0.15,1.0]); n=n/np.linalg.norm(n)
# project point to plane n dot (x-x0)=0, x0=(0,0,.3)
x0=np.array([0,0,.3]); Q=P-n*np.dot(n,P-x0)
ax.scatter([P[0]],[P[1]],[P[2]],color=red,s=40)
ax.scatter([Q[0]],[Q[1]],[Q[2]],color=green,s=40)
ax.plot([P[0],Q[0]],[P[1],Q[1]],[P[2],Q[2]],'--',color=gray,lw=2)
ax.text(P[0],P[1],P[2]+.15,'P')
ax.text(Q[0],Q[1],Q[2]-.25,'projection')
ax.set_xlabel('x'); ax.set_ylabel('y'); ax.set_zlabel('z')
ax.set_title('Orthogonal projection onto a plane')
ax.view_init(elev=23, azim=-55)
save(fig, 'plane_projection')
