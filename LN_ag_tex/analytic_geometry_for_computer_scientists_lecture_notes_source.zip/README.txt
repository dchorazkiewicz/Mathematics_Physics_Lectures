Analytic Geometry for Computer Scientists - Lecture Notes

Build instructions:
1. Ensure LaTeX with packages listed in main.tex is installed.
2. From this directory run: pdflatex main.tex && pdflatex main.tex
3. Figures are included in the figures/ directory.
4. The Python script used to generate figures is in src/make_figures.py.
