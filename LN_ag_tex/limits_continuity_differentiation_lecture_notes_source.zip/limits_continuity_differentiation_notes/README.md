# Limits, Continuity, and Differentiation - Lecture Notes

This archive contains the LaTeX source for the PDF lecture notes.

Main file:
- `lecture_notes.tex`

The graphics are produced directly inside the LaTeX source using TikZ/PGFPlots, so there are no separate image assets required.

To compile:

```bash
latexmk -pdf lecture_notes.tex
```
