# The Historical Development of Quantum Mechanics

LaTeX source for the lecture notes PDF.

Compile with:

```bash
pdflatex quantum_history_lecture_notes.tex
pdflatex quantum_history_lecture_notes.tex
```

The document uses standard TeX Live packages: geometry, amsmath, tikz, pgfplots, tcolorbox, titlesec, hyperref, fancyhdr.
