Source package for: Solving the Schrodinger Equation for the Hydrogen Atom

Compile:
  pdflatex main.tex
  pdflatex main.tex

Files:
  main.tex        - LaTeX source
  figures/        - generated figures included by the LaTeX file
  make_figures.py - script used to generate the figures

The final PDF was compiled with pdfLaTeX.
