import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Ellipse
from pathlib import Path

out = Path('figures')
out.mkdir(exist_ok=True)
plt.rcParams.update({
    'font.size': 11,
    'font.family': 'DejaVu Sans',
    'axes.spines.top': False,
    'axes.spines.right': False,
})

# 1. Solution flow
fig, ax = plt.subplots(figsize=(8.8, 4.8))
ax.set_xlim(0, 10)
ax.set_ylim(0, 6)
ax.axis('off')
boxes = [
    (0.5, 4.2, 2.3, 0.9, 'Hamiltonian\n$\\hat{H}=T+V(r)$'),
    (3.8, 4.2, 2.3, 0.9, 'Stationary equation\n$\\hat{H}\\psi=E\\psi$'),
    (7.1, 4.2, 2.3, 0.9, 'Spherical symmetry\nuse $(r,\\theta,\\varphi)$'),
    (2.2, 2.35, 2.6, 0.9, 'Separate variables\n$\\psi=R(r)Y_\\ell^m$'),
    (5.6, 2.35, 2.6, 0.9, 'Boundary conditions\nfinite + normalizable'),
    (3.9, 0.65, 2.9, 0.9, 'Quantized results\n$n,\\ell,m$ and $E_n$'),
]
for x,y,w,h,t in boxes:
    ax.add_patch(FancyBboxPatch((x,y), w,h, boxstyle='round,pad=0.04,rounding_size=0.08',
                                edgecolor='black', facecolor='#f4f4f4', lw=1.3))
    ax.text(x+w/2, y+h/2, t, ha='center', va='center')
arrows = [((2.8,4.65),(3.8,4.65)), ((6.1,4.65),(7.1,4.65)), ((8.2,4.2),(7.0,3.25)),
          ((7.1,2.8),(5.6,2.8)), ((4.8,2.35),(4.9,1.55))]
for a,b in arrows:
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle='->', mutation_scale=14, lw=1.2))
ax.text(5, 5.65, 'How the hydrogen atom is solved', ha='center', va='center', fontsize=15, fontweight='bold')
fig.tight_layout()
fig.savefig(out/'solution_flow.pdf', bbox_inches='tight')
plt.close(fig)

# 2. Energy levels
fig, ax = plt.subplots(figsize=(7.5, 5.2))
ax.set_xlim(0, 10)
ax.set_ylim(-14.5, 1.5)
ax.set_xlabel('not to scale horizontally')
ax.set_ylabel('Energy (eV)')
ax.set_xticks([])
for n in range(1,7):
    E=-13.6/n**2
    width = 7.8 - 0.7*n
    x0 = 1.0 + 0.2*n
    ax.hlines(E, x0, x0+width, lw=2)
    ax.text(x0+width+0.2, E, f'n={n}', va='center')
ax.hlines(0, 1.0, 9.0, lw=1.5, linestyles='dashed')
ax.text(9.05, 0, 'ionization limit', va='center')
# Transitions
transitions = [(4,2,3.0,'Balmer'),(3,2,4.2,'Balmer'),(2,1,6.1,'Lyman'),(5,1,7.2,'Lyman')]
for ni,nf,x,label in transitions:
    Ei=-13.6/ni**2; Ef=-13.6/nf**2
    ax.annotate('', xy=(x, Ef+0.15), xytext=(x, Ei-0.15), arrowprops=dict(arrowstyle='->', lw=1.2))
    ax.text(x+0.12, (Ei+Ef)/2, label, rotation=90, va='center', fontsize=9)
ax.set_title('Hydrogen energy levels and spectral transitions')
ax.grid(axis='y', alpha=.25)
fig.tight_layout()
fig.savefig(out/'energy_levels.pdf', bbox_inches='tight')
plt.close(fig)

# 3. Effective potential
rho = np.linspace(0.08, 18, 600)
fig, ax = plt.subplots(figsize=(7.5, 5.2))
for ell in [0,1,2,3]:
    Veff = ell*(ell+1)/(2*rho**2) - 1/rho
    ax.plot(rho, Veff, label=fr'$\ell={ell}$')
ax.set_ylim(-0.8, 1.2)
ax.set_xlim(0, 18)
ax.axhline(0, lw=0.8)
ax.set_xlabel(r'distance $r/a_0$')
ax.set_ylabel('dimensionless effective potential')
ax.set_title('Coulomb attraction plus angular-momentum barrier')
ax.legend(frameon=False)
ax.grid(alpha=.25)
fig.tight_layout()
fig.savefig(out/'effective_potential.pdf', bbox_inches='tight')
plt.close(fig)

# 4. Radial probability densities in units a0=1
r = np.linspace(0, 20, 1200)
# Normalized radial functions for hydrogen in units a0=1 (radial probability P=r^2 |R|^2)
R10 = 2*np.exp(-r)
R20 = (1/(2*np.sqrt(2)))*(2-r)*np.exp(-r/2)
R21 = (1/(2*np.sqrt(6)))*r*np.exp(-r/2)
R30 = (2/(81*np.sqrt(3)))*(27-18*r+2*r**2)*np.exp(-r/3)
curves = [(R10, '1s'), (R20, '2s'), (R21, '2p'), (R30, '3s')]
fig, ax = plt.subplots(figsize=(7.5, 5.2))
for R,label in curves:
    P = r**2 * R**2
    ax.plot(r, P, label=label)
ax.set_xlabel(r'distance $r/a_0$')
ax.set_ylabel(r'radial probability density $P(r)$')
ax.set_title('Radial probability: shell volume matters')
ax.legend(frameon=False)
ax.grid(alpha=.25)
fig.tight_layout()
fig.savefig(out/'radial_probabilities.pdf', bbox_inches='tight')
plt.close(fig)

# 5. s orbital schematic
fig, ax = plt.subplots(figsize=(5.4, 4.3))
ax.set_aspect('equal')
ax.axis('off')
for radius, alpha in [(1.8,.18),(1.3,.25),(0.85,.35),(0.4,.5)]:
    ax.add_patch(Circle((0,0), radius, facecolor='#1f77b4', edgecolor='none', alpha=alpha))
ax.add_patch(Circle((0,0), 0.08, color='black'))
ax.text(0,-2.25,'s orbital: spherical probability cloud', ha='center')
ax.set_xlim(-2.2,2.2); ax.set_ylim(-2.45,2.1)
fig.savefig(out/'s_orbital.pdf', bbox_inches='tight')
plt.close(fig)

# 6. p orbital schematic
fig, ax = plt.subplots(figsize=(5.4, 4.3))
ax.set_aspect('equal')
ax.axis('off')
ax.add_patch(Ellipse((0,0.95), width=1.25, height=1.9, angle=0, facecolor='#ff7f0e', alpha=.45, edgecolor='black'))
ax.add_patch(Ellipse((0,-0.95), width=1.25, height=1.9, angle=0, facecolor='#ff7f0e', alpha=.45, edgecolor='black'))
ax.add_patch(Circle((0,0), 0.08, color='black'))
ax.plot([-1.4,1.4],[0,0], color='black', lw=1, linestyle='--')
ax.text(0,0.15,'node', ha='center', va='bottom')
ax.text(0,-2.35,'p orbital: two lobes and a nodal plane', ha='center')
ax.set_xlim(-2.0,2.0); ax.set_ylim(-2.55,2.25)
fig.savefig(out/'p_orbital.pdf', bbox_inches='tight')
plt.close(fig)

print('figures written')
