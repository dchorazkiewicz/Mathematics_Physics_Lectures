# Differential and Integral Calculus for Absolute Beginners

This ZIP contains the LaTeX source for the lecture notes.

Compile with:

```bash
pdflatex main.tex
pdflatex main.tex
```

The figures are generated directly in LaTeX using TikZ/PGFPlots, so there are no separate image assets required.
