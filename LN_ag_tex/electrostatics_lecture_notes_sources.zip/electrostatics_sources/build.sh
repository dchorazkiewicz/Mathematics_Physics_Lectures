#!/usr/bin/env bash
set -euo pipefail
latexmk -pdf -interaction=nonstopmode electrostatics_for_cs_students.tex
