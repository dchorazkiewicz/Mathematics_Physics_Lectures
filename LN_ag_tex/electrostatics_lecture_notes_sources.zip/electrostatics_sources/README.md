# Electrostatics for Computer Science Students

Source package for the lecture notes PDF.

Build with:

```bash
latexmk -pdf -interaction=nonstopmode electrostatics_for_cs_students.tex
```

The document uses LaTeX with TikZ diagrams. There are no external image assets.
