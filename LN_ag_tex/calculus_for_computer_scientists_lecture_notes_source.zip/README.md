# Differential and Integral Calculus for Computer Scientists

Source package for the lecture notes PDF.

## Build

Run:

```bash
latexmk -pdf -interaction=nonstopmode calculus_for_computer_scientists.tex
```

The figures are stored in `figures/`. They were generated with `make_figures.py`.
