import numpy as np
import math
import matplotlib.pyplot as plt
from pathlib import Path

out = Path('/mnt/data/calculus_cs_lecture_notes/figures')
out.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({
    'font.size': 10,
    'axes.titlesize': 11,
    'axes.labelsize': 10,
    'figure.dpi': 160,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

def setup_axes(ax):
    ax.axhline(0, color='0.35', linewidth=0.8)
    ax.axvline(0, color='0.35', linewidth=0.8)
    ax.grid(True, alpha=0.25)

# 1. Limit with hole
x = np.linspace(-1.5, 3.5, 500)
y = (x**2 - 1)/(x-1)
y[np.abs(x-1)<1e-2] = np.nan
fig, ax = plt.subplots(figsize=(5.2, 3.2))
setup_axes(ax)
ax.plot(x, y, linewidth=2.2, label=r'$f(x)=\frac{x^2-1}{x-1},\ x\ne1$')
ax.scatter([1], [2], s=70, facecolors='white', edgecolors='#005f99', linewidths=2, zorder=3)
ax.scatter([1], [0.8], s=45, color='#d95f02', zorder=4)
ax.annotate('limit is 2', xy=(1,2), xytext=(1.5,2.7), arrowprops=dict(arrowstyle='->', lw=1))
ax.annotate('defined value can differ', xy=(1,0.8), xytext=(1.35,0.1), arrowprops=dict(arrowstyle='->', lw=1))
ax.set_xlim(-1.5,3.5); ax.set_ylim(-1,4)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$')
ax.legend(loc='upper left', fontsize=9)
fig.savefig(out/'limit_hole.pdf')
plt.close(fig)

# 2. Continuity/discontinuities panels as one figure with 3 axes, allowed as artifact not user visible charts.
fig, axs = plt.subplots(1,3,figsize=(9.5,2.8))
xx = np.linspace(-2,2,500)
# removable
ax=axs[0]; setup_axes(ax); ax.plot(xx, xx+1, lw=2); ax.scatter([0],[1], facecolors='white', edgecolors='#005f99', linewidths=2, s=60); ax.scatter([0],[0], color='#d95f02', s=40); ax.set_title('removable')
# jump
ax=axs[1]; setup_axes(ax); x1=np.linspace(-2,0,250); x2=np.linspace(0,2,250); ax.plot(x1, np.sin(x1)+0.2, lw=2); ax.plot(x2, np.sin(x2)+1.2, lw=2); ax.scatter([0],[0.2], facecolors='white', edgecolors='#005f99', linewidths=2, s=60); ax.scatter([0],[1.2], color='#d95f02', s=40); ax.set_title('jump')
# infinite
ax=axs[2]; setup_axes(ax); x1=np.linspace(-2,-0.08,250); x2=np.linspace(0.08,2,250); ax.plot(x1, 1/x1, lw=2); ax.plot(x2, 1/x2, lw=2); ax.set_ylim(-6,6); ax.set_title('infinite')
for ax in axs:
    ax.set_xlim(-2,2); ax.set_xlabel('$x$')
axs[0].set_ylabel('$y$')
fig.savefig(out/'discontinuities.pdf')
plt.close(fig)

# 3. Secant to tangent
f=lambda z: 0.25*z**3 - z + 1.2
fp=lambda z: 0.75*z**2 - 1
x = np.linspace(-2.2,2.5,500)
a=0.6; b=1.8
fig, ax=plt.subplots(figsize=(5.2,3.3))
setup_axes(ax)
ax.plot(x,f(x),lw=2.2,label='$f$')
# secant
m=(f(b)-f(a))/(b-a)
ax.plot(x, f(a)+m*(x-a), '--', lw=1.8, label='secant line')
mt=fp(a)
ax.plot(x, f(a)+mt*(x-a), lw=1.8, label='tangent at $a$')
ax.scatter([a,b],[f(a),f(b)],s=40)
ax.set_xlim(-2.2,2.5); ax.set_ylim(-1,3.6)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$'); ax.legend(fontsize=9)
fig.savefig(out/'secant_tangent.pdf')
plt.close(fig)

# 4. Absolute value cusp and ReLU
x=np.linspace(-3,3,500)
fig, ax=plt.subplots(figsize=(5.2,3.0))
setup_axes(ax)
ax.plot(x,np.abs(x),lw=2.2,label='$|x|$')
ax.plot(x,np.maximum(0,x),lw=2.2,label=r'ReLU$(x)=\max(0,x)$')
ax.scatter([0],[0],s=45)
ax.annotate('corner: no unique tangent', xy=(0,0), xytext=(0.55,1.4), arrowprops=dict(arrowstyle='->', lw=1))
ax.set_xlim(-3,3); ax.set_ylim(-0.5,3.2)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$'); ax.legend(fontsize=9)
fig.savefig(out/'nondifferentiable_cusp.pdf')
plt.close(fig)

# 5. Taylor approximations of exp
x=np.linspace(-2,2,500)
fig, ax=plt.subplots(figsize=(5.4,3.3))
setup_axes(ax)
ax.plot(x,np.exp(x),lw=2.4,label='$e^x$')
for n in [1,2,3,5]:
    y=sum(x**k/math.factorial(k) for k in range(n+1))
    ax.plot(x,y,lw=1.5,label=f'$T_{n}$')
ax.set_xlim(-2,2); ax.set_ylim(-0.5,8)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$'); ax.legend(ncol=2,fontsize=8)
fig.savefig(out/'taylor_exp.pdf')
plt.close(fig)

# 6. Newton method
f=lambda z: z**2-2
fp=lambda z: 2*z
x=np.linspace(0.5,2.5,500)
x0=2.3; x1=x0-f(x0)/fp(x0); x2=x1-f(x1)/fp(x1)
fig, ax=plt.subplots(figsize=(5.3,3.2))
setup_axes(ax)
ax.plot(x,f(x),lw=2.2,label='$f(x)=x^2-2$')
for i,xi in enumerate([x0,x1]):
    m=fp(xi)
    ax.plot(x, f(xi)+m*(x-xi), '--', lw=1.5, label=f'tangent at $x_{i}$')
    ax.scatter([xi],[f(xi)],s=45)
    ax.scatter([xi-f(xi)/m],[0],s=45)
ax.set_xlim(0.5,2.5); ax.set_ylim(-1,4)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$'); ax.legend(fontsize=8)
fig.savefig(out/'newton_method.pdf')
plt.close(fig)

# 7. Riemann sums lower/upper maybe
f=lambda z: 0.25*z**2+0.4*np.sin(2*z)+1.2
x=np.linspace(0,4,500)
fig, ax=plt.subplots(figsize=(5.5,3.2))
setup_axes(ax)
ax.plot(x,f(x),lw=2.2,label='$f(x)$')
n=8; a=0; b=4; dx=(b-a)/n
for i in range(n):
    left=a+i*dx; height=f(left)
    rect=plt.Rectangle((left,0),dx,height,alpha=0.28,edgecolor='0.25')
    ax.add_patch(rect)
ax.set_xlim(-0.1,4.1); ax.set_ylim(0,2.8)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$'); ax.set_title('left Riemann sum')
fig.savefig(out/'riemann_sum.pdf')
plt.close(fig)

# 8. Area under curve and signed area
x=np.linspace(-2,3,500)
f=lambda z: 0.5*z**2-z-0.5
fig, ax=plt.subplots(figsize=(5.5,3.2))
setup_axes(ax)
ax.plot(x,f(x),lw=2.2,label='$f(x)$')
mask=x<=0.8
ax.fill_between(x[mask],f(x[mask]),0,alpha=0.25,label='signed area')
mask2=(x>=0.8)&(x<=3)
ax.fill_between(x[mask2],f(x[mask2]),0,alpha=0.25)
ax.set_xlim(-2,3); ax.set_ylim(-1.5,5)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$'); ax.legend(fontsize=9)
fig.savefig(out/'signed_area.pdf')
plt.close(fig)

# 9. Numerical integration methods
f=lambda z: np.exp(-z**2)+0.2*z+0.4
x=np.linspace(0,3,500)
fig, ax=plt.subplots(figsize=(5.5,3.2))
setup_axes(ax)
ax.plot(x,f(x),lw=2.2,label='$f$')
n=6; a=0;b=3; dx=(b-a)/n
nodes=np.linspace(a,b,n+1)
ax.plot(nodes,f(nodes), marker='o', lw=1.6,label='trapezoid approximation')
for i in range(n):
    xs=np.array([nodes[i],nodes[i+1]])
    ax.fill_between(xs, np.interp(xs, xs, f(xs)), 0, alpha=0.16)
ax.set_xlim(-0.1,3.1); ax.set_ylim(0,1.9)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$'); ax.legend(fontsize=8)
fig.savefig(out/'trapezoid_rule.pdf')
plt.close(fig)

# 10. Sigmoid and derivative
x=np.linspace(-8,8,600)
s=1/(1+np.exp(-x))
fig, ax=plt.subplots(figsize=(5.5,3.1))
setup_axes(ax)
ax.plot(x,s,lw=2.2,label=r'$\sigma(x)$')
ax.plot(x,s*(1-s),lw=2.2,label=r"$\sigma'(x)$")
ax.set_xlim(-8,8); ax.set_ylim(-0.05,1.05)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$'); ax.legend(fontsize=9)
fig.savefig(out/'sigmoid_derivative.pdf')
plt.close(fig)

# 11. Gradient on contour map
x=np.linspace(-3,3,160); y=np.linspace(-3,3,160); X,Y=np.meshgrid(x,y)
Z=0.5*(X-1)**2 + 1.2*(Y+0.5)**2 + 0.4*X*Y
fig, ax=plt.subplots(figsize=(4.8,4.2))
cs=ax.contour(X,Y,Z,levels=12)
ax.clabel(cs, inline=True, fontsize=7)
pt=np.array([-1.6,1.2])
grad=np.array([pt[0]-1+0.4*pt[1], 2.4*(pt[1]+0.5)+0.4*pt[0]])
grad=grad/np.linalg.norm(grad)*1.0
ax.scatter([pt[0]],[pt[1]],s=50)
ax.arrow(pt[0],pt[1],grad[0],grad[1],head_width=0.15,length_includes_head=True,lw=1.8)
ax.text(pt[0]+grad[0]+0.1,pt[1]+grad[1],r'$\nabla f$',fontsize=11)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$'); ax.set_title('gradient is normal to level curves')
ax.set_aspect('equal')
fig.savefig(out/'gradient_contours.pdf')
plt.close(fig)

# 12. Hessian quadratic bowl
x=np.linspace(-2,2,160); y=np.linspace(-2,2,160); X,Y=np.meshgrid(x,y)
Z=X**2+0.3*Y**2+0.4*X*Y
fig, ax=plt.subplots(figsize=(5.0,3.7))
cs=ax.contourf(X,Y,Z,levels=18)
fig.colorbar(cs, ax=ax, shrink=0.85)
ax.contour(X,Y,Z,levels=10,colors='0.25',linewidths=0.6)
ax.set_xlabel('$x_1$'); ax.set_ylabel('$x_2$'); ax.set_title('quadratic loss landscape')
ax.set_aspect('equal')
fig.savefig(out/'quadratic_loss.pdf')
plt.close(fig)
