import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

out = Path('/mnt/data/matrices_systems_cs_lecture_notes/figures')
out.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    'font.size': 10,
    'axes.titlesize': 11,
    'axes.labelsize': 10,
    'figure.dpi': 160,
    'savefig.bbox': 'tight',
})

# 1. Linear transformation of unit square
A = np.array([[1.35, 0.55],[0.25, 1.15]])
square = np.array([[0,0],[1,0],[1,1],[0,1],[0,0]])
trans = square @ A.T
fig, ax = plt.subplots(figsize=(6.2,3.2))
ax.plot(square[:,0], square[:,1], '-o', label='original unit square', color='#2E86AB')
ax.plot(trans[:,0], trans[:,1], '-o', label=r'image under $A$', color='#C0392B')
for v, name in [(np.array([1,0]), r'$e_1$'), (np.array([0,1]), r'$e_2$')]:
    ax.arrow(0,0,v[0],v[1], head_width=0.04, length_includes_head=True, color='#2E86AB')
    ax.text(v[0]+0.04, v[1]+0.04, name, color='#2E86AB')
for v, name in [(A[:,0], r'$Ae_1$'), (A[:,1], r'$Ae_2$')]:
    ax.arrow(0,0,v[0],v[1], head_width=0.04, length_includes_head=True, color='#C0392B')
    ax.text(v[0]+0.04, v[1]+0.04, name, color='#C0392B')
ax.set_aspect('equal')
ax.grid(True, alpha=.25)
ax.set_xlim(-0.2, 2.2); ax.set_ylim(-0.2, 1.9)
ax.set_title('A matrix transforms basis vectors and the whole grid')
ax.legend(loc='upper left', frameon=False)
fig.savefig(out/'linear_transform_square.pdf')
plt.close(fig)

# 2. Two line systems: unique, none, infinite
x = np.linspace(-2.5, 3.5, 200)
fig, axes = plt.subplots(1,3, figsize=(9.8,3.0))
# unique
axes[0].plot(x, 2-x, color='#2E86AB', label=r'$x+y=2$')
axes[0].plot(x, (x+1)/2, color='#C0392B', label=r'$x-2y=-1$')
axes[0].scatter([1],[1], color='black', zorder=3)
axes[0].set_title('unique solution')
# none
axes[1].plot(x, 1-x, color='#2E86AB', label=r'$x+y=1$')
axes[1].plot(x, 3-x, color='#C0392B', label=r'$x+y=3$')
axes[1].set_title('no solution')
# infinite
axes[2].plot(x, 1.5-.5*x, color='#2E86AB', label=r'$x+2y=3$')
axes[2].plot(x, 1.5-.5*x, '--', color='#C0392B', label=r'$2x+4y=6$')
axes[2].set_title('infinitely many')
for ax in axes:
    ax.axhline(0, color='black', linewidth=.7); ax.axvline(0, color='black', linewidth=.7)
    ax.set_xlim(-2.5,3.5); ax.set_ylim(-2,4)
    ax.grid(True, alpha=.25)
    ax.legend(frameon=False, fontsize=8, loc='upper right')
fig.suptitle('Geometry of $2\times 2$ linear systems')
fig.savefig(out/'systems_lines_cases.pdf')
plt.close(fig)

# 3. Near singular lines
x = np.linspace(-1, 5, 300)
fig, ax = plt.subplots(figsize=(6.2,3.2))
ax.plot(x, 2 - x, color='#2E86AB', label=r'$x+y=2$')
ax.plot(x, 2.05 - 1.02*x, color='#C0392B', label=r'$1.02x+y=2.05$')
ax.scatter([2.5], [-0.5], color='black', s=25)
ax.set_xlim(-.5,4.5); ax.set_ylim(-2,3)
ax.axhline(0, color='black', linewidth=.7); ax.axvline(0, color='black', linewidth=.7)
ax.grid(True, alpha=.25)
ax.legend(frameon=False)
ax.set_title('Near-parallel equations amplify small perturbations')
fig.savefig(out/'near_singular_lines.pdf')
plt.close(fig)

# 4. Least squares projection
fig, ax = plt.subplots(figsize=(5.6,3.5))
line_x = np.linspace(-0.4, 3.2, 100)
line_y = 0.55*line_x
b = np.array([2.35, 2.2])
# Projection of b onto span a, a=(1,0.55)
a = np.array([1,0.55]); proj = a * (b@a)/(a@a)
ax.plot(line_x, line_y, color='#2E86AB', label=r'column space $\mathcal{C}(A)$')
ax.arrow(0,0,b[0],b[1], head_width=.07, length_includes_head=True, color='#C0392B')
ax.arrow(0,0,proj[0],proj[1], head_width=.07, length_includes_head=True, color='#2E86AB')
ax.plot([proj[0], b[0]], [proj[1], b[1]], '--', color='#555555')
ax.text(b[0]+.05,b[1], r'$b$', color='#C0392B')
ax.text(proj[0]+.05,proj[1]-.15, r'$A\hat{x}$', color='#2E86AB')
ax.text((proj[0]+b[0])/2+.05,(proj[1]+b[1])/2, r'$r=b-A\hat{x}$')
ax.set_aspect('equal')
ax.set_xlim(-.3,3.2); ax.set_ylim(-.2,2.7)
ax.grid(True, alpha=.25)
ax.legend(frameon=False, loc='upper left')
ax.set_title('Least squares as orthogonal projection')
fig.savefig(out/'least_squares_projection.pdf')
plt.close(fig)

# 5. Sparse matrix pattern
n=30
M=np.zeros((n,n))
for i in range(n):
    M[i,i]=1
    if i>0: M[i,i-1]=1
    if i<n-1: M[i,i+1]=1
    if i%7==0 and i+5<n: M[i,i+5]=1
fig, ax = plt.subplots(figsize=(4.0,4.0))
ax.spy(M, markersize=4, color='#2E86AB')
ax.set_title('Sparse matrix: store nonzero structure')
ax.set_xlabel('column'); ax.set_ylabel('row')
fig.savefig(out/'sparse_matrix_pattern.pdf')
plt.close(fig)

# 6. Matrix multiplication as composition of transformations
angle = np.deg2rad(35)
R = np.array([[np.cos(angle), -np.sin(angle)],[np.sin(angle), np.cos(angle)]])
S = np.array([[1.4,0],[0,0.75]])
shape = np.array([[0,0],[1,0],[.5,.8],[0,0]])
RS = shape @ (S@R).T
RthenS = shape @ R.T @ S.T
fig, ax = plt.subplots(figsize=(6.2,3.2))
ax.plot(shape[:,0], shape[:,1], '-o', color='#777777', label='original')
ax.plot(RS[:,0], RS[:,1], '-o', color='#2E86AB', label=r'$(SR)x$')
ax.plot(RthenS[:,0]+2.1, RthenS[:,1], '-o', color='#C0392B', label=r'$(RS)x$ shifted')
ax.set_aspect('equal')
ax.set_xlim(-.8,3.8); ax.set_ylim(-.5,1.8)
ax.grid(True, alpha=.25)
ax.legend(frameon=False)
ax.set_title('Matrix multiplication is composition; order matters')
fig.savefig(out/'composition_order_matters.pdf')
plt.close(fig)
