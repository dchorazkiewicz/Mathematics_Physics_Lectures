Source package for "Algebra for Computer Scientists -- Lecture Notes".

Files:
- algebra_for_computer_scientists.tex: main LaTeX source file.

Graphics are generated directly in LaTeX using TikZ/PGFPlots, so no external image files are required.
Compile with:
  pdflatex algebra_for_computer_scientists.tex
  pdflatex algebra_for_computer_scientists.tex
