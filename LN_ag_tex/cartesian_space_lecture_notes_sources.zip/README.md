# Lecture Notes on Cartesian Space

This folder contains the LaTeX source for the PDF lecture notes.

Main file:
- `main.tex`

To compile:

```bash
pdflatex main.tex
pdflatex main.tex
```

The document uses standard LaTeX packages: amsmath, amssymb, mathtools, tikz, tcolorbox, fancyhdr, titlesec, hyperref.
