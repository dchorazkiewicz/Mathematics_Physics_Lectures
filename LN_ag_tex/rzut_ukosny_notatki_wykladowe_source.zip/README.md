# Rzut ukośny - notatki wykładowe

Źródło LaTeX dokumentu `article` z marginesami 2.5 cm. Grafiki są rysowane bezpośrednio w LaTeX/TikZ/PGFPlots, więc nie ma osobnych plików graficznych.

Kompilacja:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error projectile_motion_lecture_notes.tex
```
