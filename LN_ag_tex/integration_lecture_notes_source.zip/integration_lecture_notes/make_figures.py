import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

out = Path('figures')
out.mkdir(exist_ok=True)

plt.rcParams.update({
    'font.size': 11,
    'axes.titlesize': 12,
    'axes.labelsize': 11,
    'figure.dpi': 160,
    'savefig.dpi': 220,
    'mathtext.fontset': 'dejavuserif',
})

blue = '#2F5E8E'
teal = '#2A9D8F'
orange = '#E76F51'
purple = '#6D597A'
green = '#4F772D'
gray = '#666666'
light_blue = '#DCEAF7'
light_orange = '#FBE3D5'
light_green = '#E4F0DD'

# 1. Area under curve
x = np.linspace(0, 3, 400)
f = 0.35*(x-1.2)**2 + 0.6 + 0.2*np.sin(2.2*x)
fig, ax = plt.subplots(figsize=(6.2, 3.6))
ax.plot(x, f, color=blue, lw=2.5, label=r'$y=f(x)$')
a,b = 0.5,2.6
mask = (x>=a)&(x<=b)
ax.fill_between(x[mask], 0, f[mask], color=light_blue, alpha=1)
ax.axvline(a, color=gray, lw=1, ls='--')
ax.axvline(b, color=gray, lw=1, ls='--')
ax.text(a, -0.08, r'$a$', ha='center', va='top')
ax.text(b, -0.08, r'$b$', ha='center', va='top')
ax.text(1.55, 0.35, r'$\int_a^b f(x)\,dx$', color=blue, ha='center')
ax.set_xlim(0,3); ax.set_ylim(0,1.9)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$')
ax.spines[['top','right']].set_visible(False)
ax.legend(frameon=False, loc='upper right')
fig.tight_layout()
fig.savefig(out/'area_under_curve.pdf', bbox_inches='tight')
plt.close(fig)

# 2. Riemann rectangles
x = np.linspace(0, 3, 500)
f = lambda x: 0.3*x**2 - 0.4*x + 1.1
fig, ax = plt.subplots(figsize=(6.2, 3.6))
ax.plot(x, f(x), color=blue, lw=2.2)
a,b,n = 0.3,2.8,8
dx = (b-a)/n
xs = a + np.arange(n)*dx
for xi in xs:
    ax.add_patch(plt.Rectangle((xi,0), dx, f(xi), facecolor=light_orange, edgecolor=orange, lw=1.1))
ax.text(1.55, 0.35, r'left sum: $\sum f(x_i^*)\Delta x$', color=orange, ha='center')
ax.set_xlim(0,3.1); ax.set_ylim(0,2.35)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$')
ax.spines[['top','right']].set_visible(False)
fig.tight_layout()
fig.savefig(out/'riemann_rectangles.pdf', bbox_inches='tight')
plt.close(fig)

# 3. Upper/lower sums for monotone function
x = np.linspace(0, 2.8, 500)
f = lambda x: 0.28*x**2 + 0.45
fig, ax = plt.subplots(figsize=(6.2, 3.6))
ax.plot(x, f(x), color=blue, lw=2.2)
a,b,n=0.2,2.5,6
dx=(b-a)/n
xs=a+np.arange(n)*dx
for xi in xs:
    ax.add_patch(plt.Rectangle((xi,0), dx, f(xi), facecolor='#EAF4F4', edgecolor=teal, lw=1))
    ax.add_patch(plt.Rectangle((xi,0), dx, f(xi+dx), fill=False, edgecolor=orange, lw=1.3, ls='--'))
ax.text(0.4, 1.9, 'dashed: upper sum', color=orange)
ax.text(0.4, 1.7, 'filled: lower sum', color=teal)
ax.set_xlim(0,2.8); ax.set_ylim(0,2.45)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$')
ax.spines[['top','right']].set_visible(False)
fig.tight_layout()
fig.savefig(out/'upper_lower_sums.pdf', bbox_inches='tight')
plt.close(fig)

# 4. Accumulation function
x = np.linspace(0, 2*np.pi, 600)
f = 1 + 0.65*np.sin(x)
F = x - 0.65*np.cos(x) + 0.65
fig, ax = plt.subplots(figsize=(6.2, 3.7))
ax.plot(x, f, color=teal, lw=2.2, label=r'$f(x)$')
ax.plot(x, F, color=purple, lw=2.2, label=r'$F(x)=\int_0^x f(t)\,dt$')
ax.set_xlim(0,2*np.pi); ax.set_ylim(0,7.4)
ax.set_xlabel('$x$')
ax.spines[['top','right']].set_visible(False)
ax.legend(frameon=False, loc='upper left')
ax.set_xticks([0,np.pi,2*np.pi]); ax.set_xticklabels(['0', r'$\pi$', r'$2\pi$'])
fig.tight_layout()
fig.savefig(out/'accumulation_function.pdf', bbox_inches='tight')
plt.close(fig)

# 5. Antiderivative family
x=np.linspace(-2.2,2.2,500)
base=x**3/3-x
fig, ax=plt.subplots(figsize=(6.2,3.6))
for C,col in [(-1.2,teal),(0,blue),(1.2,orange)]:
    ax.plot(x, base+C, color=col, lw=2, label=fr'$F(x)+{C:g}$')
ax.set_xlabel('$x$'); ax.set_ylabel('$y$')
ax.set_title('One derivative, many antiderivatives')
ax.spines[['top','right']].set_visible(False)
ax.legend(frameon=False, ncol=3, loc='upper center')
fig.tight_layout()
fig.savefig(out/'antiderivative_family.pdf', bbox_inches='tight')
plt.close(fig)

# 6. Area between curves
x=np.linspace(-0.2,2.4,500)
g=1.8-0.25*(x-1.1)**2
h=0.35+0.25*x
fig, ax=plt.subplots(figsize=(6.2,3.6))
ax.plot(x,g,color=blue,lw=2.2,label=r'$y=g(x)$')
ax.plot(x,h,color=orange,lw=2.2,label=r'$y=h(x)$')
a,b=0.25,2.1
mask=(x>=a)&(x<=b)
ax.fill_between(x[mask], h[mask], g[mask], color=light_green)
ax.text(1.15,1.15,r'$\int_a^b (g(x)-h(x))\,dx$',color=green,ha='center')
ax.set_xlim(-0.2,2.4); ax.set_ylim(0,2.1)
ax.spines[['top','right']].set_visible(False)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$')
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig(out/'area_between_curves.pdf', bbox_inches='tight')
plt.close(fig)

# 7. Improper integral tail
x=np.linspace(1,8,800)
f=1/x**2
fig, ax=plt.subplots(figsize=(6.2,3.6))
ax.plot(x,f,color=blue,lw=2.2,label=r'$y=1/x^2$')
ax.fill_between(x,0,f,color=light_blue)
ax.text(4.6,0.18,r'$\int_1^\infty \frac{1}{x^2}\,dx$',color=blue)
ax.set_xlim(1,8); ax.set_ylim(0,1.05)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$')
ax.spines[['top','right']].set_visible(False)
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig(out/'improper_integral.pdf', bbox_inches='tight')
plt.close(fig)

# 8. Arc length
x=np.linspace(0,3,500)
y=0.22*(x-0.2)**3-0.7*x+1.5
fig, ax=plt.subplots(figsize=(6.2,3.6))
ax.plot(x,y,color=blue,lw=2.5,label=r'$y=f(x)$')
pts=np.linspace(0.3,2.7,7)
yp=0.22*(pts-0.2)**3-0.7*pts+1.5
ax.plot(pts,yp,'o-',color=orange,lw=1.6,ms=4,label='polygonal approximation')
ax.text(1.55,0.62,r'$L=\int_a^b\sqrt{1+(f\'(x))^2}\,dx$',color=blue,ha='center')
ax.set_xlim(0,3); ax.set_ylim(0,2.0)
ax.set_xlabel('$x$'); ax.set_ylabel('$y$')
ax.spines[['top','right']].set_visible(False)
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig(out/'arc_length.pdf', bbox_inches='tight')
plt.close(fig)

