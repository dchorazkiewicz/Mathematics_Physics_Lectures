# Projectile Motion Lecture Notes

This archive contains the LaTeX source for the English PDF lecture notes on projectile motion.

Main file:
- `projectile_motion_lecture_notes.tex`

The PDF was compiled with `pdflatex`. The figures are generated directly in LaTeX using TikZ/PGFPlots, so there are no external graphics assets required.
