# Equations of Motion - Kinematics Lecture Notes

Generated LaTeX source for the PDF lecture notes.
Compile with:

```bash
pdflatex main.tex
pdflatex main.tex
```

The document is designed as a narrative lecture on pure kinematics: position, velocity, acceleration, differentiation, integration, initial conditions, graphs, trajectories, and interpretation.
