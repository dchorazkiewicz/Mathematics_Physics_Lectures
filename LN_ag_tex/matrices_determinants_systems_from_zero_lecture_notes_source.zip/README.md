# Matrices, Determinants, and Linear Systems for Absolute Beginners

LaTeX source for the lecture notes.

Compile with:

```bash
latexmk -pdf main.tex
```

The document uses TikZ for diagrams, so no external graphics are required.
