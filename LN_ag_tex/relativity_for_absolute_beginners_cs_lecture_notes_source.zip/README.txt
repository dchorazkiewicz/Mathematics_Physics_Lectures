Source package for "Relativity from Zero for Computer Science Students".
Compile with:
  pdflatex relativity_zero_cs_notes.tex
  pdflatex relativity_zero_cs_notes.tex

The figures are generated directly in LaTeX using TikZ/PGFPlots.
