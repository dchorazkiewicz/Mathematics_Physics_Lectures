# Electromagnetism from Zero - Lecture Notes

This archive contains the LaTeX source for the PDF lecture notes.

Compile with:

```bash
pdflatex main.tex
pdflatex main.tex
```

The document uses standard LaTeX packages: amsmath, amssymb, tikz, tcolorbox, hyperref, fancyhdr, listings, booktabs, and lmodern.
