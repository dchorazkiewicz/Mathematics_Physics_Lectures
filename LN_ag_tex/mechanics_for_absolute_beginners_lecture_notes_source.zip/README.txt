Source files for: Classical Mechanics from Zero
Compile with: pdflatex mechanics_for_absolute_beginners_lecture_notes.tex
Run pdflatex at least twice for table of contents and page references.
