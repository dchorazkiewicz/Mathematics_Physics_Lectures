Source package for the PDF lecture notes "Calculating Determinants".

Main LaTeX file:
- determinants_lecture_notes.tex

Compile with:
  latexmk -pdf determinants_lecture_notes.tex

No external image assets are required. The cover graphic is generated with TikZ inside the LaTeX source.
