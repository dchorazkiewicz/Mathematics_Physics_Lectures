# Astrophysics Lecture Notes

This package contains the LaTeX source for the PDF lecture notes:

- `astrophysics_lecture_notes.tex`

The figures are generated directly in LaTeX using TikZ/PGFPlots, so no separate image assets are required.

Compile with:

```bash
pdflatex astrophysics_lecture_notes.tex
pdflatex astrophysics_lecture_notes.tex
```
