Circular Motion Lecture Notes - narrative revised version.
Compile with: pdflatex main.tex (twice for table of contents).
Generated using LaTeX with TikZ/PGFPlots; no external image assets are required.
