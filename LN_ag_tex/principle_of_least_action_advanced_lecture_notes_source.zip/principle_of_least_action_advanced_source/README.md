# The Principle of Least Action - Advanced Lecture Notes

Compile with:

```bash
pdflatex main.tex
pdflatex main.tex
```

The document uses standard LaTeX packages: amsmath, amssymb, mathtools, tikz, pgfplots, tcolorbox, hyperref, fancyhdr, titlesec.
