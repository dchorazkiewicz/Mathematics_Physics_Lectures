# Matematyczne wprowadzenie do notacji naukowej i zapisu numerycznego

Źródło LaTeX dla pliku PDF.

Kompilacja:

```bash
xelatex main.tex
xelatex main.tex
```

Plik główny: `main.tex`.
