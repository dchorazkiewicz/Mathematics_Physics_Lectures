# Classical Mechanics for High School Students

This source package contains the LaTeX source for the lecture notes.

Compile with:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The document uses standard TeX Live packages: amsmath, siunitx, tikz, pgfplots, tcolorbox, fancyhdr, hyperref.
