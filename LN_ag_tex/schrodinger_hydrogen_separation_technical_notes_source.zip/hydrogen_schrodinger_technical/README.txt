Source package for: Solving the Schrodinger Equation for the Hydrogen Atom - Separation of Variables.

Compile with:
  xelatex -interaction=nonstopmode -output-directory build main.tex
  xelatex -interaction=nonstopmode -output-directory build main.tex

Figures are in the figures/ directory and are included by main.tex.
