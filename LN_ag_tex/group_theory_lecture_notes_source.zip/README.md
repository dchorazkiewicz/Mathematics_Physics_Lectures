# Group Theory Lecture Notes

This archive contains the LaTeX source for the PDF lecture notes.

Main file:

- `group_theory_lecture_notes.tex`

Compile with:

```bash
pdflatex group_theory_lecture_notes.tex
pdflatex group_theory_lecture_notes.tex
```

No external graphics are required. Diagrams are generated with TikZ inside the LaTeX source.
