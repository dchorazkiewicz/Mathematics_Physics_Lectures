Źródła LaTeX do PDF: "Jak przekształcać wzory w fizyce".
Kompilacja:
  lualatex main.tex
  lualatex main.tex

W dokumencie nie użyto zewnętrznych grafik; schematy są generowane w TikZ.
