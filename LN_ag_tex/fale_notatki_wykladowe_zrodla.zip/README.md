# Notatki wykładowe: fale

Źródła LaTeX do pliku `fale_notatki_wykladowe.pdf`.

Kompilacja:

```bash
pdflatex fale_notatki.tex
pdflatex fale_notatki.tex
pdflatex fale_notatki.tex
```

Dokument nie używa zewnętrznych grafik; wykresy są generowane bezpośrednio w LaTeX/TikZ/PGFPlots.
