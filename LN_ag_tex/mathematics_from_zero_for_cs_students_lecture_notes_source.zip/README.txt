Source package for "Mathematics from Zero for Computer Science Students".

Compile with:
  pdflatex math_zero_cs_notes.tex
  pdflatex math_zero_cs_notes.tex

The document uses standard LaTeX packages: amsmath, amssymb, tikz, pgfplots, tcolorbox, listings, hyperref, geometry, fancyhdr.
